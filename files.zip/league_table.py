"""
Livescore-style Games Ranking System
=====================================
Reads per-game results (score + differential) for any number of players
and any number of games, and produces a standings table just like a
livescore.com league table:

    Rank | Player | P | W | L | +/- | Pts

Design goals (scalability):
- Add a new player any time  -> just add a Player() and results for them.
- Add a new game any time    -> just call add_result(...) with a new game id.
- Sorting rules, columns, and win/loss thresholds are all configurable.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple


# ---------------------------------------------------------------------------
# Core data model
# ---------------------------------------------------------------------------

@dataclass
class Result:
    """A single player's result in a single game."""
    game: str
    score: int   # points awarded for that game (e.g. 3 = win, 0 = loss)
    diff: int    # score differential for that game (e.g. +5, -3)


@dataclass
class Player:
    name: str
    results: List[Result] = field(default_factory=list)

    def add_result(self, game: str, score: int, diff: int):
        self.results.append(Result(game, score, diff))

    # --- derived stats -----------------------------------------------------
    @property
    def played(self) -> int:
        return len(self.results)

    @property
    def points(self) -> int:
        return sum(r.score for r in self.results)

    @property
    def diff_total(self) -> int:
        return sum(r.diff for r in self.results)

    def wins(self, win_score: int = 3) -> int:
        return sum(1 for r in self.results if r.score == win_score)

    def losses(self, win_score: int = 3) -> int:
        return sum(1 for r in self.results if r.score != win_score)


class LeagueTable:
    """Holds all players and produces a sortable, printable standings table."""

    def __init__(self, win_score: int = 3):
        self.win_score = win_score
        self.players: Dict[str, Player] = {}
        self.games: List[str] = []          # keeps game order, e.g. G1, G2, ...
        self._game_set = set()              # O(1) membership check as games grow

    # --- data entry ----------------------------------------------------
    def add_result(self, player_name: str, game: str, score: int, diff: int):
        if player_name not in self.players:
            self.players[player_name] = Player(player_name)
        if game not in self._game_set:
            self._game_set.add(game)
            self.games.append(game)
        self.players[player_name].add_result(game, score, diff)

    def add_game_round(self, game: str, results: Dict[str, Tuple[int, int]]):
        """Convenience: add a whole game/round at once.
        results = {player_name: (score, diff), ...}
        """
        for player_name, (score, diff) in results.items():
            self.add_result(player_name, game, score, diff)

    def add_results_bulk(self, entries: List[Tuple[str, str, int, int]]):
        """Add many (player, game, score, diff) rows in one call.
        Useful for CSV/bulk imports so the GUI doesn't need a round trip
        per row when a user pastes in hundreds of results at once.
        """
        for player_name, game, score, diff in entries:
            self.add_result(player_name, game, score, diff)

    # --- editing ---------------------------------------------------------
    def remove_player(self, player_name: str):
        self.players.pop(player_name, None)

    def remove_game(self, game: str):
        if game in self._game_set:
            self._game_set.discard(game)
            self.games.remove(game)
        for p in self.players.values():
            p.results = [r for r in p.results if r.game != game]

    # --- persistence -------------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "win_score": self.win_score,
            "games": self.games,
            "results": [
                {"player": p.name, "game": r.game, "score": r.score, "diff": r.diff}
                for p in self.players.values()
                for r in p.results
            ],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "LeagueTable":
        league = cls(win_score=data.get("win_score", 3))
        for entry in data.get("results", []):
            league.add_result(entry["player"], entry["game"], entry["score"], entry["diff"])
        # preserve original game order even if a game currently has no results
        for g in data.get("games", []):
            if g not in league.games:
                league.games.append(g)
        return league

    def save_json(self, path: str):
        import json
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_json(cls, path: str) -> "LeagueTable":
        import json
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)

    # --- standings -------------------------------------------------------
    def standings(self) -> List[Player]:
        """Sort by points desc, then goal/score differential desc."""
        return sorted(
            self.players.values(),
            key=lambda p: (p.points, p.diff_total),
            reverse=True,
        )

    # --- display ---------------------------------------------------------
    def print_table(self, title: str = "STANDINGS"):
        rows = self.standings()

        header = f"{'Rank':<5}{'Player':<12}{'P':>4}{'W':>4}{'L':>4}{'+/-':>6}{'Pts':>6}"
        line = "-" * len(header)

        print(f"\n{title}")
        print(line)
        print(header)
        print(line)
        for rank, p in enumerate(rows, start=1):
            diff_str = f"{p.diff_total:+d}"
            print(
                f"{rank:<5}{p.name:<12}{p.played:>4}{p.wins(self.win_score):>4}"
                f"{p.losses(self.win_score):>4}{diff_str:>6}{p.points:>6}"
            )
        print(line)

    def print_game_by_game(self):
        """Optional: livescore-style breakdown per game/player, like the
        original scoresheet (row=player, column=game)."""
        header = f"{'Player':<12}" + "".join(f"{g:>10}" for g in self.games)
        print("\n" + header)
        print("-" * len(header))
        for name, p in self.players.items():
            row = f"{name:<12}"
            by_game = {r.game: r for r in p.results}
            for g in self.games:
                if g in by_game:
                    r = by_game[g]
                    row += f"{r.score}({r.diff:+d})".rjust(10)
                else:
                    row += "-".rjust(10)
            print(row)


# ---------------------------------------------------------------------------
# Data transcribed from the scoresheet photo
# (score, differential) per player per game
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    league = LeagueTable(win_score=3)

    league.add_game_round("G1", {
        "Darius":  (3, +5),
        "Steve":   (0, -5),
        "Winner":  (0, -3),
        "Moses":   (0, -1),
        "Edward":  (3, +3),
    })

    league.add_game_round("G2", {
        "Darius":  (3, +1),
        "Steve":   (3, +2),
        "Winner":  (3, +3),
        "Moses":   (0, -2),
        "Edward":  (3, -3),
    })

    league.add_game_round("G3", {
        "Darius":  (3, +3),
        "Steve":   (3, +3),
        "Winner":  (0, 0),
        "Moses":   (0, -3),
        "Edward":  (0, +3),
    })

    league.add_game_round("G4", {
        "Darius":  (3, +3),
        "Steve":   (3, +1),
        "Winner":  (0, -3),
        "Moses":   (0, -3),
        "Edward":  (0, -1),
    })

    # --- Add a new game any time (scalability demo) ----------------------
    # league.add_game_round("G5", {"Darius": (3, +2), "Steve": (0, -2), ...})

    # --- Add a brand-new player any time ----------------------------------
    # league.add_result("NewPlayer", "G5", 3, +4)

    league.print_game_by_game()
    league.print_table(title="FULL RANKING TABLE (after G4)")

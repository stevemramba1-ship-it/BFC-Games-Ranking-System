"""
League Table Desktop App
=========================
A small Tkinter GUI around league_table.py.

- Enter a round of results (game id + player/score/diff rows)
- View live standings (Rank/Player/P/W/L/+/-/Pts)
- View a game-by-game breakdown grid
- Save / load your data as a .json file so it persists between sessions

Run directly with:  python gui_app.py
Package as a standalone exe with PyInstaller (see README.md).
"""

import json
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from league_table import LeagueTable

APP_TITLE = "League Table"
DEFAULT_SAVE_NAME = "league_data.json"


class RoundRow(ttk.Frame):
    """One player/score/diff input row inside the 'add round' form."""

    def __init__(self, master, on_remove, known_players):
        super().__init__(master)
        self.player_var = tk.StringVar()
        self.score_var = tk.StringVar()
        self.diff_var = tk.StringVar()

        # Editable combobox: existing players auto-complete (avoids
        # near-duplicate names once you have dozens/hundreds of players),
        # but typing a new name still works fine for new players.
        self.player_combo = ttk.Combobox(self, textvariable=self.player_var, width=16, values=known_players)
        self.player_combo.grid(row=0, column=0, padx=2)
        ttk.Entry(self, textvariable=self.score_var, width=8).grid(row=0, column=1, padx=2)
        ttk.Entry(self, textvariable=self.diff_var, width=8).grid(row=0, column=2, padx=2)
        ttk.Button(self, text="✕", width=3, command=lambda: on_remove(self)).grid(row=0, column=3, padx=2)

    def set_known_players(self, known_players):
        self.player_combo["values"] = known_players

    def get_values(self):
        return self.player_var.get().strip(), self.score_var.get().strip(), self.diff_var.get().strip()


class LeagueApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("780x560")
        self.minsize(640, 480)

        self.league = LeagueTable(win_score=3)
        self.current_file = None
        self.round_rows = []

        self._build_menu()
        self._build_layout()
        self.refresh_all()

    # ------------------------------------------------------------------ menu
    def _build_menu(self):
        menubar = tk.Menu(self)

        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="New (clear all data)", command=self.new_league)
        filemenu.add_command(label="Open...", command=self.load_data)
        filemenu.add_command(label="Save", command=self.save_data)
        filemenu.add_command(label="Save As...", command=self.save_data_as)
        filemenu.add_separator()
        filemenu.add_command(label="Export standings CSV...", command=self.export_csv)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.destroy)
        menubar.add_cascade(label="File", menu=filemenu)

        self.config(menu=menubar)

    # ---------------------------------------------------------------- layout
    def _build_layout(self):
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=8, pady=8)

        self.entry_tab = ttk.Frame(notebook)
        self.standings_tab = ttk.Frame(notebook)
        self.breakdown_tab = ttk.Frame(notebook)

        notebook.add(self.entry_tab, text="Enter Results")
        notebook.add(self.standings_tab, text="Standings")
        notebook.add(self.breakdown_tab, text="Game-by-Game")

        self.notebook = notebook
        notebook.bind("<<NotebookTabChanged>>", lambda e: self.refresh_all())

        self._build_entry_tab()
        self._build_standings_tab()
        self._build_breakdown_tab()

    # --- Enter Results tab --------------------------------------------------
    def _build_entry_tab(self):
        top = ttk.Frame(self.entry_tab)
        top.pack(fill="x", padx=8, pady=8)

        ttk.Label(top, text="Game ID (e.g. G1):").grid(row=0, column=0, sticky="w")
        self.game_id_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.game_id_var, width=16).grid(row=0, column=1, padx=6)

        ttk.Label(top, text="Win score (points for a win):").grid(row=0, column=2, sticky="w", padx=(20, 0))
        self.win_score_var = tk.StringVar(value=str(self.league.win_score))
        ttk.Entry(top, textvariable=self.win_score_var, width=6).grid(row=0, column=3, padx=6)
        ttk.Button(top, text="Apply", command=self.apply_win_score).grid(row=0, column=4)

        header = ttk.Frame(self.entry_tab)
        header.pack(fill="x", padx=8)
        ttk.Label(header, text="Player", width=16).grid(row=0, column=0, padx=2)
        ttk.Label(header, text="Score", width=8).grid(row=0, column=1, padx=2)
        ttk.Label(header, text="Diff (+/-)", width=8).grid(row=0, column=2, padx=2)

        # Scrollable area for player rows -- keeps the form usable even
        # with a large roster, instead of growing the window forever.
        rows_container = ttk.Frame(self.entry_tab)
        rows_container.pack(fill="both", expand=False, padx=8, pady=4)
        rows_canvas = tk.Canvas(rows_container, height=160, highlightthickness=0)
        rows_scrollbar = ttk.Scrollbar(rows_container, orient="vertical", command=rows_canvas.yview)
        self.rows_frame = ttk.Frame(rows_canvas)
        self.rows_frame.bind("<Configure>", lambda e: rows_canvas.configure(scrollregion=rows_canvas.bbox("all")))
        rows_canvas.create_window((0, 0), window=self.rows_frame, anchor="nw")
        rows_canvas.configure(yscrollcommand=rows_scrollbar.set)
        rows_canvas.pack(side="left", fill="both", expand=True)
        rows_scrollbar.pack(side="right", fill="y")

        btns = ttk.Frame(self.entry_tab)
        btns.pack(fill="x", padx=8, pady=6)
        ttk.Button(btns, text="+ Add player row", command=self.add_round_row).pack(side="left")
        ttk.Button(btns, text="Submit round", command=self.submit_round).pack(side="left", padx=8)

        ttk.Separator(self.entry_tab).pack(fill="x", padx=8, pady=8)

        # --- Bulk import: paste many rows at once (name,score,diff per line) ---
        bulk = ttk.LabelFrame(self.entry_tab, text="Bulk import a round (paste CSV: player,score,diff — one per line)")
        bulk.pack(fill="x", padx=8, pady=(0, 8))
        self.bulk_game_var = tk.StringVar()
        bulk_top = ttk.Frame(bulk)
        bulk_top.pack(fill="x", padx=6, pady=(6, 0))
        ttk.Label(bulk_top, text="Game ID for this import:").pack(side="left")
        ttk.Entry(bulk_top, textvariable=self.bulk_game_var, width=12).pack(side="left", padx=6)
        self.bulk_text = tk.Text(bulk, height=5)
        self.bulk_text.pack(fill="x", padx=6, pady=6)
        self.bulk_text.insert("1.0", "Alice,3,+5\nBob,0,-5\nCara,3,+2")
        bulk_btns = ttk.Frame(bulk)
        bulk_btns.pack(fill="x", padx=6, pady=(0, 6))
        ttk.Button(bulk_btns, text="Import CSV file...", command=self.import_csv_file).pack(side="left")
        ttk.Button(bulk_btns, text="Import pasted rows", command=self.import_bulk_text).pack(side="left", padx=8)

        ttk.Separator(self.entry_tab).pack(fill="x", padx=8, pady=8)

        rm = ttk.Frame(self.entry_tab)
        rm.pack(fill="x", padx=8)
        ttk.Label(rm, text="Remove player:").grid(row=0, column=0, sticky="w")
        self.remove_player_var = tk.StringVar()
        self.remove_player_combo = ttk.Combobox(rm, textvariable=self.remove_player_var, width=16, state="readonly")
        self.remove_player_combo.grid(row=0, column=1, padx=6)
        ttk.Button(rm, text="Remove", command=self.remove_player).grid(row=0, column=2)

        ttk.Label(rm, text="Remove game:").grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.remove_game_var = tk.StringVar()
        self.remove_game_combo = ttk.Combobox(rm, textvariable=self.remove_game_var, width=16, state="readonly")
        self.remove_game_combo.grid(row=1, column=1, padx=6, pady=(6, 0))
        ttk.Button(rm, text="Remove", command=self.remove_game).grid(row=1, column=2, pady=(6, 0))

        for _ in range(3):
            self.add_round_row()

    def add_round_row(self):
        row = RoundRow(self.rows_frame, self.remove_round_row, list(self.league.players.keys()))
        row.pack(anchor="w", pady=1)
        self.round_rows.append(row)

    def remove_round_row(self, row):
        row.destroy()
        self.round_rows.remove(row)

    def import_bulk_text(self):
        game = self.bulk_game_var.get().strip()
        if not game:
            messagebox.showerror(APP_TITLE, "Enter a Game ID for this import first.")
            return
        raw = self.bulk_text.get("1.0", "end").strip()
        if not raw:
            messagebox.showerror(APP_TITLE, "Paste some rows first (player,score,diff).")
            return
        self._import_csv_rows(raw.splitlines(), game)

    def import_csv_file(self):
        path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        game = self.bulk_game_var.get().strip()
        if not game:
            messagebox.showerror(APP_TITLE, "Enter a Game ID for this import first.")
            return
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
        self._import_csv_rows(lines, game)

    def _import_csv_rows(self, lines, game):
        import csv as csv_mod
        entries = []
        errors = []
        for i, line in enumerate(lines, start=1):
            line = line.strip()
            if not line:
                continue
            parts = next(csv_mod.reader([line]))
            if len(parts) < 3:
                errors.append(f"Line {i}: expected 'player,score,diff'")
                continue
            name, score, diff = parts[0].strip(), parts[1].strip(), parts[2].strip()
            try:
                entries.append((name, game, int(score), int(diff)))
            except ValueError:
                errors.append(f"Line {i}: score/diff must be whole numbers")

        if errors:
            messagebox.showerror(APP_TITLE, "Some rows were skipped:\n" + "\n".join(errors[:10]))
        if not entries:
            return

        self.league.add_results_bulk(entries)
        self.refresh_all()
        messagebox.showinfo(APP_TITLE, f"Imported {len(entries)} row(s) for game '{game}'.")

    def apply_win_score(self):
        try:
            self.league.win_score = int(self.win_score_var.get())
        except ValueError:
            messagebox.showerror(APP_TITLE, "Win score must be a whole number.")
            return
        self.refresh_all()

    def submit_round(self):
        game = self.game_id_var.get().strip()
        if not game:
            messagebox.showerror(APP_TITLE, "Enter a Game ID first (e.g. G1).")
            return

        entries = []
        for row in self.round_rows:
            name, score, diff = row.get_values()
            if not name:
                continue
            try:
                score_i = int(score)
                diff_i = int(diff)
            except ValueError:
                messagebox.showerror(APP_TITLE, f"Score/diff for '{name}' must be whole numbers.")
                return
            entries.append((name, score_i, diff_i))

        if not entries:
            messagebox.showerror(APP_TITLE, "Add at least one player row with a name.")
            return

        for name, score_i, diff_i in entries:
            self.league.add_result(name, game, score_i, diff_i)

        # reset the form for the next round
        for row in list(self.round_rows):
            self.remove_round_row(row)
        for _ in range(3):
            self.add_round_row()
        self.game_id_var.set("")

        self.refresh_all()
        messagebox.showinfo(APP_TITLE, f"Round '{game}' added for {len(entries)} player(s).")

    def remove_player(self):
        name = self.remove_player_var.get()
        if name:
            self.league.remove_player(name)
            self.refresh_all()

    def remove_game(self):
        game = self.remove_game_var.get()
        if game:
            self.league.remove_game(game)
            self.refresh_all()

    # --- Standings tab -------------------------------------------------------
    def _build_standings_tab(self):
        top = ttk.Frame(self.standings_tab)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Button(top, text="Refresh", command=self.refresh_all).pack(side="left")
        ttk.Label(top, text="Search player:").pack(side="left", padx=(16, 4))
        self.standings_filter_var = tk.StringVar()
        self.standings_filter_var.trace_add("write", lambda *a: self.refresh_standings())
        ttk.Entry(top, textvariable=self.standings_filter_var, width=20).pack(side="left")

        cols = ("rank", "player", "p", "w", "l", "diff", "pts")
        tree_frame = ttk.Frame(self.standings_tab)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.standings_tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=15)
        headings = {"rank": "Rank", "player": "Player", "p": "P", "w": "W", "l": "L", "diff": "+/-", "pts": "Pts"}
        widths = {"rank": 50, "player": 160, "p": 50, "w": 50, "l": 50, "diff": 70, "pts": 60}
        for c in cols:
            self.standings_tree.heading(c, text=headings[c])
            self.standings_tree.column(c, width=widths[c], anchor="center")
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.standings_tree.yview)
        self.standings_tree.configure(yscrollcommand=vsb.set)
        self.standings_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

    # --- Game-by-Game tab ------------------------------------------------
    def _build_breakdown_tab(self):
        # Vertical + horizontal scrollbars: with many games the column
        # count grows unbounded, and with many players so do the rows.
        frame = ttk.Frame(self.breakdown_tab)
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        self.breakdown_tree = ttk.Treeview(frame, show="headings", height=15)
        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.breakdown_tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=self.breakdown_tree.xview)
        self.breakdown_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.breakdown_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

    # ---------------------------------------------------------------- refresh
    def refresh_all(self):
        self.refresh_standings()
        self.refresh_breakdown()
        self.refresh_remove_lists()

    def refresh_standings(self):
        for item in self.standings_tree.get_children():
            self.standings_tree.delete(item)
        query = getattr(self, "standings_filter_var", None)
        query = query.get().strip().lower() if query else ""
        for rank, p in enumerate(self.league.standings(), start=1):
            if query and query not in p.name.lower():
                continue
            self.standings_tree.insert(
                "", "end",
                values=(rank, p.name, p.played, p.wins(self.league.win_score),
                        p.losses(self.league.win_score), f"{p.diff_total:+d}", p.points),
            )

    def refresh_breakdown(self):
        tree = self.breakdown_tree
        for item in tree.get_children():
            tree.delete(item)
        cols = ["player"] + self.league.games
        tree["columns"] = cols
        tree.heading("player", text="Player")
        tree.column("player", width=140, anchor="w")
        for g in self.league.games:
            tree.heading(g, text=g)
            tree.column(g, width=90, anchor="center")

        for name, p in self.league.players.items():
            by_game = {r.game: r for r in p.results}
            row = [name]
            for g in self.league.games:
                if g in by_game:
                    r = by_game[g]
                    row.append(f"{r.score} ({r.diff:+d})")
                else:
                    row.append("-")
            tree.insert("", "end", values=row)

    def refresh_remove_lists(self):
        player_names = list(self.league.players.keys())
        self.remove_player_combo["values"] = player_names
        self.remove_game_combo["values"] = list(self.league.games)
        for row in self.round_rows:
            row.set_known_players(player_names)

    # ------------------------------------------------------------ file menu
    def new_league(self):
        if messagebox.askyesno(APP_TITLE, "Clear all current data?"):
            self.league = LeagueTable(win_score=3)
            self.win_score_var.set("3")
            self.current_file = None
            self.refresh_all()

    def load_data(self):
        path = filedialog.askopenfilename(filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            self.league = LeagueTable.load_json(path)
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Could not load file:\n{e}")
            return
        self.current_file = path
        self.win_score_var.set(str(self.league.win_score))
        self.refresh_all()

    def save_data(self):
        if not self.current_file:
            self.save_data_as()
            return
        self.league.save_json(self.current_file)
        messagebox.showinfo(APP_TITLE, f"Saved to {self.current_file}")

    def save_data_as(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            initialfile=DEFAULT_SAVE_NAME,
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        self.league.save_json(path)
        self.current_file = path
        messagebox.showinfo(APP_TITLE, f"Saved to {path}")

    def export_csv(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile="standings.csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        import csv
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Rank", "Player", "P", "W", "L", "+/-", "Pts"])
            for rank, p in enumerate(self.league.standings(), start=1):
                writer.writerow([rank, p.name, p.played, p.wins(self.league.win_score),
                                  p.losses(self.league.win_score), p.diff_total, p.points])
        messagebox.showinfo(APP_TITLE, f"Exported to {path}")


if __name__ == "__main__":
    app = LeagueApp()
    app.mainloop()
